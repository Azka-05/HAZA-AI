const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");
const chatForm = document.getElementById("chat-form");

chatForm.addEventListener("submit", (e) => {
  e.preventDefault();
  sendMessage();
});

function sendMessage() {
  const message = userInput.value.trim();
  if (!message) return;

  addMessage("You", message, "user");
  userInput.value = "";

  // Simulate AI response with a small delay
  setTimeout(() => {
    let reply = getCoachReply(message);
    addMessage("Coach", reply, "coach");
  }, 700);
}

function addMessage(sender, text, role) {
  const p = document.createElement("p");
  p.classList.add(role);
  p.innerHTML = `<strong>${sender}:</strong> ${text}`;
  chatBox.appendChild(p);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function getCoachReply(message) {
  const msg = message.toLowerCase();
  if (msg.includes("tired")) {
    return "Take a short break, then continue at a slower pace.";
  }
  if (msg.includes("pain")) {
    return "Listen to your body; if pain persists, consult a professional.";
  }
  if (msg.includes("warmup")) {
    return "A proper warm-up is essential: try light cardio and dynamic stretches.";
  }
  if (msg.includes("motivation")) {
    return "Keep your goals in mind and remember why you started!";
  }
  return "Let's focus on form and breathing.";
}

